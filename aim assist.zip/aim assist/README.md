## Installation

1. Install a version of [Python](https://www.python.org/downloads/) 3.8 or later.

2. Navigate to the root directory. Use the package manager [pip](https://pip.pypa.io/en/stable/) to install the necessary dependencies.

```
open requirments.bat
```

## Usage
```           
python aimassist.py (make sure to type this in correct directory)
```